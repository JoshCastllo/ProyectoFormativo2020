Esta demo ha sido desarrollada con las siguientes herramientas:
- WAPP v7.3.11 (PHP 7.3.11 / PostgreSQL 11.5)
- Materialize v1.0.0
- jQuery v3.4.1
- Google Chrome

Crear una base de datos llamada coffeeshop y luego hacer la importación con el archivo database.sql

Las credenciales para la conexión con la base de datos son (ubicadas en core/helpers/database.php):
    Servidor: localhost (127.0.0.1)
    Usuario: postgres
    Contraseña: postgres
    Puerto por defecto (5432)

Inicio del sitio privado (al ingresar por primera vez se pedirá crear un usuario):
    localhost/coffeeshop/views/dashboard/

Inicio del sitio público:
    localhost/coffeeshop/views/commerce/

Si se opta por utilizar XAMPP, es necesario acceder a la siguiente dirección C:\xampp\php y hacer lo siguiente:
1. Ubicar y abrir el archvio php.ini
2. Buscar la línea ;extension=pdo_pgsql
3. Borrar el ; que esta al inicio de la línea
4. Guardar los cambios y cerrar el archivo
5. Reiniciar Apache

Para realizar lo anterior es necesario que Apache de WAPP no este funcionando (hay que detener el servicio).