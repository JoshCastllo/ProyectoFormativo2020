<?php
/*
*	Clase para manejar la tabla productos de la base de datos. Es clase hija de Validator.
*/
class Marcas extends Validator
{
    // Declaración de atributos (propiedades).
    private $id = null;
    private $nombre = null;
    private $img = null;
    private $ruta = '../../../resources/img/';

    /*
    *   Métodos para asignar valores a los atributos.
    */
    public function setId($value)
    {
        if ($this->validateNaturalNumber($value)) {
            $this->id = $value;
            return true;
        } else {
            return false;
        }
    }

    public function setNombre($value)
    {
        if ($this->validateAlphanumeric($value, 1, 50)) {
            $this->nombre = $value;
            return true;
        } else {
            return false;
        }
    }

    public function setImg($file)
    {
        if ($this->validateImageFile($file, 500, 500)) {
            $this->img = $this->getImageName();
            $this->archivo = $file;
            return true;
        } else {
            return false;
        }
    }

    /*
    *   Métodos para obtener valores de los atributos.
    */
    public function getId()
    {
        return $this->id;
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function getImg()
    {
        return $this->img;
    }
    public function getRuta()
    {
        return $this->ruta;
    }
    
    /*
    *   Métodos para realizar las operaciones SCRUD (search, create, read, update, delete).
    */
    public function searchMarca($value)
    {
        $sql = 'SELECT id_marca, imagen_m, nombre_mar
                FROM marca
                WHERE nombre_mar ILIKE ?
                ORDER BY nombre_mar';
        $params = array("%$value%");
        return Database::getRows($sql, $params);
    }

    public function createMarca()
    {
        if ($this->saveFile($this->archivo, $this->ruta, $this->img)) {
            $sql = 'INSERT INTO marca(id_marca, nombre_mar, imagen_m)
                    VALUES(DEFAULT, ?, ?)';
            $params = array($this->nombre, $this->img);
            return Database::executeRow($sql, $params);
        } else {
            return false;
        }
    }

    public function readAllMarca()
    {
        $sql = 'SELECT id_marca, imagen_m, nombre_mar
                FROM marca
                ORDER BY nombre_mar';
        $params = null;
        return Database::getRows($sql, $params);
    }

    public function readOneMarca()
    {
        $sql = 'SELECT id_marca, nombre_mar
                FROM marca
                WHERE id_marca = ?';
        $params = array($this->id);
        return Database::getRow($sql, $params);
    }

    public function updateMarca()
    {
        if ($this->saveFile($this->archivo, $this->ruta, $this->img)) {
            $sql = 'UPDATE marca
                    SET nombre_mar = ?, imagen_m = ?
                    WHERE id_marca = ?';
            $params = array($this->nombre, $this->img, $this->id);
        } else {
            $sql = 'UPDATE marca
                    SET nombre_mar = ?
                    WHERE id_marca = ?';
            $params = array($this->nombre, $this->id);
        }
        return Database::executeRow($sql, $params);
    }

    public function deleteMarca()
    {
        $sql = 'DELETE FROM marca
                WHERE id_marca = ?';
        $params = array($this->id);
        return Database::executeRow($sql, $params);
    }

    /*
    *   Métodos para generar gráficas.
    */
    public function cantidadProductosCategoria()
    {
        $sql = 'SELECT nombre_categoria, COUNT(id_producto) cantidad
                FROM productos INNER JOIN categorias USING(id_categoria)
                GROUP BY id_categoria, nombre_categoria';
        $params = null;
        return Database::getRows($sql, $params);
    }
}
?>