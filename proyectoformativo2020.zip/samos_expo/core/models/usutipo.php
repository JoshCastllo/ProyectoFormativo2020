<?php
/*
*	Clase para manejar la tabla categorias de la base de datos. Es clase hija de Validator.
*/
class Tipousuario extends Validator
{
    // Declaración de atributos (propiedades).
    private $id = null;
    private $nombretipousu = null;

    /*
    *   Métodos para asignar valores a los atributos.
    */
    public function setId($value)
    {
        if ($this->validateNaturalNumber($value)) {
            $this->id = $value;
            return true;
        } else {
            return false;
        }
    }

    public function setNombretipousu($value)
    {
        if($this->validateAlphanumeric($value, 1, 50)) {
            $this->nombretipousu = $value;
            return true;
        } else {
            return false;
        }
    }

    /*
    *   Métodos para obtener valores de los atributos.
    */
    public function getId()
    {
        return $this->id;
    }

    public function getNombretipousu()
    {
        return $this->nombretipousu;
    }
    

    /*
    *   Métodos para realizar las operaciones SCRUD (search, create, read, update, delete).
    */
    public function searchTipou($value)
    {
        $sql = 'SELECT id_tipousu, tipo_usu
                FROM tipo_usuario
                WHERE tipo_usu ILIKE ? 
                ORDER BY tipo_usu';
        $params = array("%$value%");
        return Database::getRows($sql, $params);
    }

    public function createTipou()
    {
        
        $sql = 'INSERT INTO tipo_usuario(tipo_usu) VALUES(?)';
            $params = array($this->nombretipousu);
            return Database::executeRow($sql, $params);
    }

    public function readAllTipou()
    {
        $sql = 'SELECT id_tipousu, tipo_usu
                FROM tipo_usuario
                ORDER BY tipo_usu';
        $params = null;
        return Database::getRows($sql, $params);
    }

    public function readOneTipou()
    {
        $sql = 'SELECT id_tipousu, tipo_usu FROM tipo_usuario WHERE id_tipousu = ?';
        $params = array($this->id);
        return Database::getRow($sql, $params);
    }

    public function updateTipou()
    {
        $sql = 'UPDATE tipo_usuario SET tipo_usu = ? WHERE id_tipousu = ?';
            $params = array($this->nombretipousu , $this->id);  
        return Database::executeRow($sql, $params);
    }

    public function deleteTipou()
    {
        $sql = 'DELETE FROM tipo_usuario WHERE id_tipousu = ?';
        $params = array($this->id);
        return Database::executeRow($sql, $params);
    }
}
?>