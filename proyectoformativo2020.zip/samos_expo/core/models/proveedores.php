<?php
/*
*	Clase para manejar la tabla categorias de la base de datos. Es clase hija de Validator.
*/
class Proveedor extends Validator
{
    // Declaración de atributos (propiedades).
    private $id = null;
    private $nombre = null;
    private $apellidos = null;
    private $telefono = null;
    private $correo = null;

    /*
    *   Métodos para asignar valores a los atributos.
    */
    public function setId($value)
    {
        if ($this->validateNaturalNumber($value)) {
            $this->id = $value;
            return true;
        } else {
            return false;
        }
    }

    public function setNombre($value)
    {
        if($this->validateAlphanumeric($value, 1, 50)) {
            $this->nombre = $value;
            return true;
        } else {
            return false;
        }
    }

    public function setApellidos($value)
    {
        if ($this->validateAlphabetic($value, 1, 50)) {
            $this->apellidos = $value;
            return true;
        } else {
            return false;
        }
    }

    public function setTelefono($value)
    {
        if ($this->validateNaturalNumber($value)) {
            $this->telefono = $value;
            return true;
        } else {
            return false;
        }
    }

    public function setCorreo($value)
    {
        if ($this->validateEmail($value)) {
            $this->correo = $value;
            return true;
        } else {
            return false;
        }
    }

    /*
    *   Métodos para obtener valores de los atributos.
    */
    public function getId()
    {
        return $this->id;
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function getApellidos()
    {
        return $this->apellidos;
    }

    public function getTelefono()
    {
        return $this->telefono;
    }

    public function getCorreo()
    {
        return $this->correo;
    }
    

    /*
    *   Métodos para realizar las operaciones SCRUD (search, create, read, update, delete).
    */
    public function searchProveedor($value)
    {
        $sql = 'SELECT id_proveedor, nombre_prov, apellido_prov, telefono_prov, correo_prov
                FROM proveedor
                WHERE nombre_prov ILIKE ? OR apellido_prov ILIKE ?
                ORDER BY nombre_prov';
        $params = array("%$value%", "%$value%");
        return Database::getRows($sql, $params);
    }

    public function createProveedor()
    {
        
        $sql = 'INSERT INTO proveedor(nombre_prov, apellido_prov, telefono_prov, correo_prov) VALUES(?, ?, ?, ?)';
            $params = array($this->nombre, $this->apellidos, $this->telefono, $this->correo);
            return Database::executeRow($sql, $params);
    }

    public function readAllProveedor()
    {
        $sql = 'SELECT id_proveedor, nombre_prov, apellido_prov, telefono_prov, correo_prov
                FROM proveedor
                ORDER BY nombre_prov';
        $params = null;
        return Database::getRows($sql, $params);
    }

    public function readOneProveedor()
    {
        $sql = 'SELECT id_proveedor, nombre_prov, apellido_prov, telefono_prov, correo_prov FROM proveedor WHERE id_proveedor = ?';
        $params = array($this->id);
        return Database::getRow($sql, $params);
    }

    public function updateProveedor()
    {
        $sql = 'UPDATE proveedor SET nombre_prov = ?, apellido_prov = ?, telefono_prov = ?, correo_prov = ? WHERE id_proveedor = ?';
        $params = array($this->nombre, $this->apellidos, $this->telefono, $this->correo , $this->id);  
        return Database::executeRow($sql, $params);
    }

    public function deleteProveedor()
    {
        $sql = 'DELETE FROM proveedor WHERE id_proveedor = ?';
        $params = array($this->id);
        return Database::executeRow($sql, $params);
    }
}
?>