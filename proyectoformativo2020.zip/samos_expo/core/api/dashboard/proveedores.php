<?php
require_once('../../helpers/database.php');
require_once('../../helpers/validator.php');
require_once('../../models/proveedores.php');

// Se comprueba si existe una acción a realizar, de lo contrario se finaliza el script con un mensaje de error.
if (isset($_GET['action'])) {
    // Se crea una sesión o se reanuda la actual para poder utilizar variables de sesión en el script.
    session_start();
    // Se instancia la clase correspondiente.
    $proveedor = new Proveedor;
    // Se declara e inicializa un arreglo para guardar el resultado que retorna la API.
    $result = array('status' => 0, 'message' => null, 'exception' => null);
    // Se verifica si existe una sesión iniciada como administrador, de lo contrario se finaliza el script con un mensaje de error.
    if (isset($_SESSION['id_usuario'])) {
        // Se compara la acción a realizar cuando un administrador ha iniciado sesión.
        switch ($_GET['action']) {
            case 'readAll':
                if ($result['dataset'] = $proveedor->readAllProveedor()) {
                    $result['status'] = 1;
                } else {
                    $result['exception'] = 'No hay proveedores regitrados';
                }
                break;
            case 'search':
                $_POST = $proveedor->validateForm($_POST);
                if ($_POST['search'] != '') {
                    if ($result['dataset'] = $proveedor->searchProveedor($_POST['search'])) {
                        $result['status'] = 1;
                        $rows = count($result['dataset']);
                        if ($rows > 1) {
                            $result['message'] = 'Se encontraron '.$rows.' coincidencias';
                        } else {
                            $result['message'] = 'Solo existe una coincidencia';
                        }
                    } else {
                        $result['exception'] = 'No hay coincidencias';
                    }
                } else {
                    $result['exception'] = 'Ingrese un valor para buscar';
                }
                break;
            case 'create':
                $_POST = $proveedor->validateForm($_POST);
                
                if ($proveedor->setNombre($_POST['nombre_prove'])) {
                    if ($proveedor->setApellidos($_POST['apellido_prove'])) {
                        if ($proveedor->setTelefono($_POST['telefono_prove'])) {
                            if ($proveedor->setCorreo($_POST['correo_prove'])) {
                                if ($proveedor->createProveedor()) {
                                    $result['status'] = 1;
                                    $result['message'] = 'Proveedor agregado correctamente';
                                } else {
                                    $result['exception'] = Database::getException(); 
                                }    
                            } else {
                                $result['exception']='coloque un correo';
                            }                        
                        } else {
                            $result['exception']='Coloque el numero de telefono';
                        }                        
                    } else {
                        $result['exception']='Completar el campo de apellidos';
                    }                    
                } else {
                    $result['exception']='Completar el campo de nombre';
                }
                

                break;
            case 'readOne':
                if ($proveedor->setId($_POST['id_proveedor'])) {
                    if ($result['dataset'] = $proveedor->readOneProveedor()) {
                        $result['status'] = 1;
                    } else {
                        $result['exception'] = 'proveedor inexistente';
                    }
                } else {
                    $result['exception'] = 'Categoría incorrecta';
                }
                break;
            case 'update':                
                $_POST = $proveedor->validateForm($_POST);

                if ($proveedor->setId($_POST['id_proveedor'])) {
                    if ($data = $proveedor->readOneProveedor()) {
                        if ($proveedor->setNombre($_POST['nombre_prove'])) {
                            if ($proveedor->setApellidos($_POST['apellido_prove'])) {
                                if ($proveedor->setTelefono($_POST['telefono_prove'])) {
                                    if ($proveedor->setCorreo($_POST['correo_prove'])) {
                                        if ($proveedor->updateProveedor()) {
                                            $result['status'] = 1;
                                            $result['message'] = 'Proveedor modificado correctamente';
                                        } else {
                                            $result['exception'] = database::getException();
                                        }
                                    } else {
                                        $result['exception']='correo incorrecto';
                                    }
                                } else {
                                    $result['exception']='telefono incorrecto';
                                }
                            } else {
                                $result['exception']='apellido incorrecto'; 
                            }
                        } else {
                            $result['exception']='Nombre incorrecto';   
                        }
                    } else {
                        $result['exception']='proveedor inexistente';
                    }
                } else {
                    $result['exception']='Proveedor incorrecto';
                }
                

                break;
            case 'delete':
                if ($proveedor->setId($_POST['id_proveedor'])) {
                    if ($proveedor->deleteProveedor()) {
                        $result['status'] = 1;
                        $result['message'] = 'Usuario eliminado correctamente';
                    } else {
                        $result['exception'] = Database::getException();
                    }    
                } else {
                    $result['exception'] = 'usuario incorrecto';
                }
                break;
            default:
                exit('Acción no disponible');
        }
        // Se indica el tipo de contenido a mostrar y su respectivo conjunto de caracteres.
        header('content-type: application/json; charset=utf-8');
        // Se imprime el resultado en formato JSON y se retorna al controlador.
        print(json_encode($result));
    } else {
        exit('Acceso no disponible');
    }
} else {
    exit('Recurso denegado');
}
?>