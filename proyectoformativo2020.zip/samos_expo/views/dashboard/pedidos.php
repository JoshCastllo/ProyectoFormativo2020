<?php
require_once('../../core/helpers/dashboard.php');
Dashboard::headerTemplate('Pedidos Realizados');
?>



<?php
Dashboard::footerTemplate('main.js');
?>
