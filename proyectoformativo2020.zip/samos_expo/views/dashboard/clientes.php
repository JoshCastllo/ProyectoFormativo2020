<?php
require_once('../../core/helpers/dashboard.php');
Dashboard::headerTemplate('Manage Customers');
?>

<div class="row">
    <!-- Formulario de búsqueda -->
    <form method="post" id="search-form">
        <div class="input-field col s6 m4">
            <i class="material-icons prefix white-text">search</i>
            <input id="search" type="text" name="search"/>
            <label for="search">Look for</label>
        </div>
        <div class="input-field col s6 m4">
            <button type="submit" class="btn waves-effect green tooltipped" data-tooltip="Searh"><i class="material-icons">check_circle</i></button>
        </div>
    </form>
    <!--<div class="input-field center-align col s12 m4">
         Enlace para abrir caja de dialogo (modal) al momento de crear un nuevo registro 
        <a href="#" onclick="openCreateModal()" class="btn waves-effect indigo tooltipped" data-tooltip="Crear"><i class="material-icons">add_circle</i></a>
    </div>-->
</div>

<table class=" highlight centered">
    <!-- Cabeza de la tabla para mostrar los títulos de las columnas -->
    <thead class="white-text">
        <tr>
            <th>NAME</th>
            <th>LASTNAME</th>
            <TH>DUI</TH>
            <TH>PHONE</TH>
            <TH>E-MAIL</TH>
            <th>DIRECTION</th>
            <th>ESTATE</th>
            <th>ACCIONES</th>
            <th>ORDERS</th>
        </tr>
    </thead>
    <!-- Cuerpo de la tabla para mostrar un registro por fila -->
    <tbody id="tbody-rows" class="white-text">
    </tbody>
</table>

<!-- Componente Modal para mostrar una caja de dialogo -->
<div id="save-modal" class="modal">
    <div class="modal-content blue-grey lighten-4">
        <h4 id="modal-title" class="center-align"></h4>
        <!-- Formulario para crear o actualizar un registro -->
        <form method="post" id="save-form" enctype="multipart/form-data">
            <!-- Campo oculto para asignar el id del registro al momento de modificar -->
            <input class="hide" type="text" id="id_cliente" name="id_cliente"/>
            <div class="row">
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">account_circle</i>
                    <input id="nombrecli" type="text" name="nombrecli" class="validate" required/>
                    <label for="nombrecli">Name</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">account_circle</i>
                    <input id="apellidocli" type="text" name="apellidocli" class="validate" required/>
                    <label for="apellidocli">Lastname</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">account_circle</i>
                    <input id="direccion" type="text" name="direccion" class="validate" required/>
                    <label for="direccion">Direction</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">email</i>
                    <input id="correocli" type="email" name="correocli" class="validate" required/>
                    <label for="correocli">E-mail</label>
                </div>
                <div class="input-field col s12 m3">
                    <i class="material-icons prefix">phone</i>
                    <input id="duicli" type="text" name="duicli" class="validate" required/>
                    <label for="duicli">Dui</label>
                </div>
                <div class="input-field col s12 m3">
                    <i class="material-icons prefix">person</i>
                    <input id="telefonocli" type="tel" name="telefonocli" class="validate" required/>
                    <label for="telefonocli">Phone</label>
                </div>
                <div class="col s12 m6">
                    <p>
                        <div class="switch">
                            <i class="small material-icons prefix">assignment_late</i>
                            <label>
                                <i class="material-icons">visibility_off</i>
                                <input id="estado_cli" type="checkbox" name="estado_cli" checked/>
                                <span class="lever grey-text"></span>
                                <i class="material-icons">visibility</i>
                            </label>
                        </div>
                    </p>
                </div>
            </div>
            <div class="row center-align">
                <a href="#" class="btn waves-effect grey tooltipped modal-close" data-tooltip="Cancel"><i class="material-icons">cancel</i></a>
                <button type="submit" class="btn waves-effect green tooltipped" data-tooltip="Save"><i class="material-icons">save</i></button>
            </div>
        </form>
    </div>
</div>

<!-- Componente Modal para mostrar una caja de dialogo -->
<div id="save-modal" class="modal">
    <div class="modal-content blue-grey lighten-4">
        <h4 id="modal-title" class="center-align"></h4>
        <!-- Formulario para crear o actualizar un registro -->
        <form method="post" id="pedidos" enctype="multipart/form-data">
            <!-- Campo oculto para asignar el id del registro al momento de modificar -->
            <input class="hide" type="text" id="id_pedido" name="id_pedido"/>

            <table class=" highlight centered">
                <!-- Cabeza de la tabla para mostrar los títulos de las columnas -->
                <thead>
                    <tr>
                        <th>CANTIDAD</th>
                        <th>PRODUCTO</th>
                        <TH>PRECIO</TH>
                        
                    </tr>
                </thead>
                <!-- Cuerpo de la tabla para mostrar un registro por fila -->
                <tbody id="tbody-pedidos">
                </tbody>
            </table>

            <div class="row center-align">
                <a href="#" class="btn waves-effect grey tooltipped modal-close" data-tooltip="Cancelar"><i class="material-icons">cancel</i></a>
                <button type="submit" class="btn waves-effect blue tooltipped" data-tooltip="Guardar"><i class="material-icons">save</i></button>
            </div>
        </form>
    </div>
</div>


<?php
Dashboard::footerTemplate('clientes.js');
?>