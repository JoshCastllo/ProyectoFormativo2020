<?php
require_once('../../core/helpers/commerce.php');
Commerce::headerTemplate('Productos por categría');
?>

<!-- Contenedor para mostrar los productos por categoría -->
<div class="container">
    <h4 class="center blue-text" id="title"></h4>
    <div class="row" id="productos"></div>
</div>

<!-- Contenedor para mostrar efecto parallax con una altura de 300px e imagen aleatoria -->
<div class="parallax-container">
    <div class="parallax">
        <img id="parallax">
    </div>
</div>

<?php
Commerce::footerTemplate('productos.js');
?>