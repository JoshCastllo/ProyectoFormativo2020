<?php
require_once('../../core/helpers/commerce.php');
Commerce::headerTemplate('Detalles del producto');
?>

<!-- Contenedor para mostrar el detalle del producto seleccionado previamente -->
<div class="container">
    <h4 class="center blue-text" id="title">Detalles del producto</h4>
    <div class="row" id="detalle">
        <!-- Componente Horizontal Card -->
        <div class="card horizontal">
            <div class="card-image">
                <img id="imagen" src="../../resources/img/unknown.png">
            </div>
            <div class="card-stacked">
                <div class="card-content">
                    <h3 id="nombre" class="header"></h3>
                    <p id="descripcion"></p>
                    <p>Precio (US$) <b id="precio"></b></p>
                </div>
                <div class="card-action">
                    <!-- Formulario de cantidad para agregar el producto al carrito de compras -->
                    <form method="post" id="shopping-form">
                        <div class="row center">
                            <div class="input-field col s12 m6">
                                <i class="material-icons prefix">list</i>
                                <input id="cantidad" type="number" name="cantidad" min="1" class="validate">
                                <label for="cantidad">Cantidad</label>
                            </div>
                            <div class="input-field col s12 m6">
                                <button type="submit" class="btn waves-effect waves-light blue tooltipped" data-tooltip="Agregar al carrito"><i class="material-icons">add_shopping_cart</i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Contenedor para mostrar efecto parallax con una altura de 300px e imagen aleatoria -->
<div class="parallax-container">
	<div class="parallax">
        <img id="parallax">
    </div>
</div>

<?php
Commerce::footerTemplate('detalle.js');
?>