<?php
require_once('../../core/helpers/commerce.php');
Commerce::headerTemplate('Acceder');
?>

<!-- Contenedor para mostrar los formularios de Crear cuenta e Iniciar sesión -->
<div class="container">
    <h4 class="center-align">ACCEDER</h4>
    <!-- Componente Tabs para menejar los formularios bajo un esquema de pestañas -->
    <ul class="tabs center-align">
        <li class="tab"><a href="#cuenta">CREAR CUENTA</a></li>
        <li class="tab"><a href="#sesion">INICIAR SESIÓN</a></li>
    </ul>

    <!-- Formulario para crear cuenta -->
    <div id="cuenta">
        <form method="post" id="register-form">
            <!-- Campo oculto para asignar el token del reCAPTCHA -->
            <input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response"/>
            <div class="row">
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">account_box</i>
                    <input type="text" id="nombres_cliente" name="nombres_cliente" maxlength="50" class="validate" required/>
                    <label for="nombres_cliente">Nombres</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">account_box</i>
                    <input type="text" id="apellidos_cliente" name="apellidos_cliente" maxlength="50" class="validate" required/>
                    <label for="apellidos_cliente">Apellidos</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">email</i>
                    <input type="email" id="correo_cliente" name="correo_cliente" maxlength="100" class="validate" required/>
                    <label for="correo_cliente">Correo electrónico</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">phone</i>
                    <input type="number" id="telefono_cliente" name="telefono_cliente" min="20000000" max="79999999" class="validate" required/>
                    <label for="telefono_cliente">Teléfono</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">security</i>
                    <input type="password" id="clave_cliente" name="clave_cliente" class="validate" required/>
                    <label for="clave_cliente">Contraseña</label>
                </div>
                <div class="input-field col s12 m6">
                    <i class="material-icons prefix">security</i>
                    <input type="password" id="confirmar_clave" name="confirmar_clave" class="validate" required/>
                    <label for="confirmar_clave">Confirmar contraseña</label>
                </div>
                <div class="input-field col s12">
                    <i class="material-icons prefix">place</i>
                    <input type="text" id="direccion_cliente" name="direccion_cliente" maxlength="100" class="validate" required/>
                    <label for="direccion_cliente">Dirección</label>
                </div>
                <label class="center-align col s12">
                    <input type="checkbox" id="condicion" name="condicion" required/>
                    <span>Acepto <a href="#terminos" class="modal-trigger">términos y condiciones</a></span>
                </label>
            </div>
            <div class="row center-align">
                <div class="col s12">
                    <button type="submit" class="btn waves-effect blue tooltipped" data-tooltip="Registrar"><i class="material-icons">send</i></button>
                </div>
            </div>
        </form>
    </div>

    <!-- Formulario para iniciar sesión -->
    <div id="sesion">
        <form method="post" id="sesion-form">
            <div class="row">
                <div class="input-field col s12 m6 offset-m3">
                    <i class="material-icons prefix">email</i>
                    <input type="email" id="usuario" name="usuario" class="validate" required/>
                    <label for="usuario">Correo electrónico</label>
                </div>
                <div class="input-field col s12 m6 offset-m3">
                    <i class="material-icons prefix">security</i>
                    <input type="password" id="clave" name="clave" class="validate" required/>
                    <label for="clave">Contraseña</label>
                </div>
            </div>
            <div class="row center-align">
                <button type="submit" class="btn waves-effect blue tooltipped" data-tooltip="Ingresar"><i class="material-icons">send</i></button>
            </div>
        </form>
    </div>
</div>

<!-- Contenedor para mostrar efecto parallax con una altura de 300px e imagen aleatoria -->
<div class="parallax-container">
    <div class="parallax">
        <img id="parallax">
    </div>
</div>

<!-- Importación del archivo para que funcione el reCAPTCHA. Para más información https://developers.google.com/recaptcha/docs/v3 -->
<script src="https://www.google.com/recaptcha/api.js?render=6LdBzLQUAAAAAJvH-aCUUJgliLOjLcmrHN06RFXT"></script>

<?php
Commerce::footerTemplate('acceder.js');
?>